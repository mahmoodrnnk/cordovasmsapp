function getLocation() {

    var watchID = navigator.geolocation.getCurrentPosition(onSuccess, onError);
    
    function onSuccess(position) {
        document.getElementById("textarea").value =
                       + position.coords.latitude          + ',' +
                       + position.coords.longitude         + '';

    };
    
    // onError Callback receives a PositionError object
    //
    function onError(error) {
        Materialize.toast('code: '    + error.code    + '\n' +
              'message: ' + error.message + '\n');
    };
    
 

}
var app = {
    sendSms: function() {
        var number = document.getElementById('icon_telephone').value.toString(); /* iOS: ensure number is actually a string */
        var message = document.getElementById('textarea').value;
        console.log("number=" + number + ", message= " + message);

        //CONFIGURATION
        var options = {
            replaceLineBreaks: false, // true to replace \n by a new line, false by default
            android: {
                intent: ''  // send SMS with the native android SMS messaging
                //intent: '' // send SMS without open any other app
            }
        };

        var success = function () { alert('Message sent successfully'); };
        var error = function (e) { alert('Message Failed:' + e); };
        sms.send(number, message, options, success, error);
    }
};

